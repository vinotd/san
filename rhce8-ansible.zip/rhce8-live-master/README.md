# Github repository for RHCE8 Live class
# by Sander van Vugt @ learning.oreilly.com
# mail@sandervanvugt.nl
